#include "filemanager_imp.h"
#include <iostream>
#include <string.h>
#include "utils.h"

//Duda general, ¿Los buffers hay que cambiarlos dependiendo del valor que llegue?

filemanager_imp::filemanager_imp(int clientID)
{
    client_fd=clientID;
    //Cual seria el path

}
void filemanager_imp::run()
{
    char* buffr=0x00;
    int bufferLen=0;

    int typeOp=0;
    recvMSG(client_fd,(void**)&buffr,&bufferLen);
    typeOp=((int*)buffr)[0];
    delete[] buffr;

    switch(typeOp)
    {
        case OP_EXIT:
        {
            this->salir=true;

        }break;
        
        case OP_LIST:{
            int bufflen=0;
            string* nombre=0x00;
            //Listar los archivos
            vector<string*>* lista=nullptr;
            lista= fileman->listFiles();
            int nFiles= lista->size();

            //Mandamos el numero de ficheros
            sendMSG(client_fd,&nFiles,sizeof(int));
            //Ahora mandamos mensaje para cada fichero
            for(int i=0; i<nFiles;i++)
            {
                //Enviamos la longuitud del mensaje
                bufflen=lista->at(i)->length()+1;
                sendMSG(client_fd,&bufflen,sizeof(int));
                //Mandamos el nombre
                nombre=lista->at(i);
                sendMSG(client_fd,nombre->c_str(),nombre->length()+1);
                
            }
            fileman->freeListedFiles(lista);
            


        }break;

        case OP_READ:{
            //Recibira nombre del ficherlo, recibira el *&data y entero de %datalength
            char* fileName=0x00;
            char* data=0x00;
            unsigned long int dataLength=0;
            unsigned long int filenameLen=0;
            //Recibes el tamaño
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            filenameLen=((int*)buffr)[0];
            delete[] buffr;
            //Recibes el nombre
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            fileName=buffr;

            fileman-> readFile(fileName,data,dataLength);

            sendMSG(client_fd,&dataLength,sizeof(int));

            sendMSG(client_fd,data,dataLength);  

            delete[] fileName;

            /*
            //Recibimos el tamaño del fichero
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            filenameLen=((int*)buffr)[0];
            delete[] buffr;
            //Recibimos el fichero
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            fileName=buffr;
            
            //Recibimos el data del ficheor
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            data=buffr;
            //
            fileman-> readFile(fileName,data,filenameLen);
            //------------------------------------
            delete[] buffr;*/


        }break; 

        case OP_WRITE:{
            char* buffr=0x00;
            int bufferLen=0;
            //Recibe 3 paramtros 
            char* fileName=0x00;
            char* data=0x00;
            unsigned int fileNameLength=0;
            unsigned int dataLen=0;
            //Recibimos el fileNameLength
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            fileNameLength=((int*)buffr)[0];
            delete[] buffr;
            //Recibimos el filename
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            fileName=buffr;
            //delete[] buffr;
            //Recibimos el tamaño del data
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            dataLen=((int*)buffr)[0];
            //delete[]buffr;
            //Recibimos el data
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            data=buffr;

            //A continuacion realiza la operacion
            fileman-> writeFile(fileName,data,dataLen);

            delete[] data;
            delete[] fileName;

        }break;
        
        case INIT_DIR:
        {
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            fileman=new FileManager(std::string(buffr));
        }break;

        default:
        {
            std::cout<<"ERROR: operacion no soportada.";
            exit(0);
        }break;
    }
}

filemanager_imp::~filemanager_imp()
{
    closeConnection(client_fd);
    delete fileman;
}