#include"utils.h"
#include "filemanager_imp.h"
#include "filemanager.h"
#include <iostream>
#include <string>

void clientHandler(int clientID)
{
    filemanager_imp* op=new filemanager_imp(clientID);

    while(!op->salir)
        op->run();

    delete op;
}

int main(int argc,char** argv)
{

        int server_fd=initServer(8081);

        while(true)
        {
            if(checkNewConnections())
            {
                int newID=getNewConnection();
                std::thread* newClient=new std::thread(clientHandler,newID);
            }
            usleep(1000);
        }

        return 0;
}
