#include "utils.h"
#include "filemanager_stub.h"
#include "filemanager.h"
#include <iostream>
#include <string>

int main(int argc, char** argv)
{
    fileManager_stub *fm=new fileManager_stub("./dirprueba/");

    //*fm=fileManager_stub("./dirprueba/");
    char* data=nullptr;
    unsigned long int fileLen=0;
    vector<string*>* vfiles= fm->listFiles();
    cout<<"Cantidad de ficheros: "<<vfiles->size()<<endl;
    cout<<"Lista de ficheros en el directorio de prueba:\n";

    for(unsigned int i=0;i<vfiles->size();++i)
    {
        cout<<"Fichero: "<<vfiles->at(i)->c_str()<<endl;
    }
    cout<<"Leyendo el primer fichero del directorio de prueba:\n";
    fm->readFile(&(*(vfiles->at(0)))[0],data,fileLen);
    cout<<"Escribiendo el primer fichero del directorio de prueba:\n";
    fm->writeFile(&(*(vfiles->at(0)))[0],data,fileLen);
    cout<<"Escribiendo el primer fichero del directorio en el directorio local:\n";
    FILE* f=fopen(&(*(vfiles->at(0)))[0], "w");
    fwrite(data, fileLen, 1, f);
    fclose(f);
    cout<<"Liberando lista de ficheros:\n";
    fm->freeListedFiles(vfiles);

    cout<<"Liberando datos de fichero leído:\n";

    delete[] data;
    delete fm;
    return 0;


}