#include "multmatrix_stub.h"
#include "multmatrix.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <unistd.h>

/**
 * @brief multMatrix::multMatrix Constructor de la clase multMatrix.
 * No tiene parámetros y sólo inicializa el generador de números aleatorios
 */
multMatrix_stub::multMatrix_stub()
{
    this->socket=initClient("192.168.0.113",8081);
    srand(getpid());
    
}
/**
 * @brief multMatrix::readMatrix Método que lee un fichero de disco duro y devuelve un objeto "matrix_t". En caso de no
 * existir el fichero, devolverá NULL. El fichero se encuetra en formato texto, la primera línea contiene el número de
 * filas y columnas, y las siguientes líneas son los datos (un dato por línea)
 * @param fileName Nombre del fichero
 * @return En caso de éxito, retorna una estructura de tipo "matrix_t" con los datos del fichero. En otro caso retornará NULL
 */
matrix_t *multMatrix_stub::readMatrix(const char *fileName)
{
    char* buffr=0x00;
    int* puntero=0x00;
    int bufferLen=0;
    int typeOP=0;
    sendMSG(socket,&typeOP,sizeof(int));

    sendMSG(socket,fileName,strlen(fileName)+1);
    //malloc
    matrix_t* mtx=new matrix_t[1];

    recvMSG(socket,(void**)&buffr,&bufferLen);
    mtx->rows=((int*)buffr)[0];
    delete[]buffr;
    
    recvMSG(socket,(void**)&buffr,&bufferLen);
    mtx->cols=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&puntero,&bufferLen);
    mtx->data=puntero;
    
    /*
    FILE* f=fopen(fileName,"r");
    if(f==0)
    {
        std::cout<< "ERROR: Fichero " << std::string(fileName) <<" no existe\n";
        return NULL;
    }
    //matrix_t* matrix=new matrix_t[1];

    //fscanf(f,"%d %d",&matrix->rows,&matrix->cols);
    std::cout<<"Leidos fila y columna: "<<matrix->rows<<" "<<matrix->cols<<"\n";
    //matrix->data=new int[matrix->rows*matrix->cols];
    for(int i=0;i<mtx->rows*mtx->cols;i++)
        {
            fscanf(f,"%d",&mtx->data[i]);
        }

    fclose(f);*/
    return mtx;
}

/**
 * @brief multMatrix::multMatrices Método que implementa la multiplicación de matrices.
 * Recibe dos matrices de tipo matrix_t y devuelve otra matriz matrix_t con el resultado
 * de la multiplicación
 * @param m1 Primera matriz en la multiplicación
 * @param m2 Segunda matriz en la multiplicación
 * @return En caso de éxito, retorna una estructura de tipo matrix_t, con el resultado de la multiplicación.
 *  NULL en otro caso.
 */
matrix_t *multMatrix_stub::multMatrices(matrix_t *m1, matrix_t* m2)
{
    char* buffr=0x00;
    int* puntero=0x00;
    int bufferLen=0;
    matrix_t* mtx=new matrix_t[1];
    int typeOP=MULT;
    sendMSG(socket,&typeOP,sizeof(int));
    //Mandamos la primera matriz
    sendMSG(socket,&m1->rows,sizeof(int));
    sendMSG(socket,&m1->cols,sizeof(int));
    sendMSG(socket,m1->data,(m1->rows*m1->cols*sizeof(int)));
    
    //Mandamos la segunda matriz
    sendMSG(socket,&m2->rows,sizeof(int));
    sendMSG(socket,&m2->cols,sizeof(int));
    sendMSG(socket,m2->data,(m2->rows*m2->cols*sizeof(int)));
    
    //Recibimos la matriz resultado
    recvMSG(socket,(void**)&buffr,&bufferLen);
    mtx->rows=((int*)buffr)[0];
    delete[]buffr;
    
    recvMSG(socket,(void**)&buffr,&bufferLen);
    mtx->cols=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&puntero,&bufferLen);
    mtx->data=puntero;

    /*
    if(m1->cols!=m2->rows)
    {
        std::cout<<"ERROR: Matrices no compatibles\n";
        return NULL;
    }

    //matrix_t* mres=new matrix_t[1];
    mres->rows=m1->rows;
    mres->cols=m2->cols;
    mres->data=new int[mres->rows*mres->cols];
    for(int i=0;i<m1->rows;i++)//each row m1
    {
        for(int j=0;j<m2->cols;j++) //each col m2
        {
           mres->data[i*mres->cols+j]=0;

           for(int k=0;k<m1->cols;k++) //dot mult m1 row by m2 col
           {
                mres->data[i*mres->cols+j]+=m1->data[i*m1->cols+k]*m2->data[k*m2->cols+j];
           }
        }
    }*/

    return mtx;
}
/**
 * @brief multMatrix::writeMatrix Método que escribe a fichero el contenido de la matriz pasada por parámetros
 * @param m Matriz cuyos datos se escribirán en fichero
 * @param fileName Nombre del fichero a generar
 */
void multMatrix_stub::writeMatrix(matrix_t *m,const char* fileName)
{
    matrix_t* mtx=new matrix_t[1];
    int typeOP=WRITE;
    sendMSG(socket,&typeOP,sizeof(int));
    //Mandamos primero el fileName
    sendMSG(socket,fileName,strlen(fileName)+1);

    //Mandamos primero la matriz
    sendMSG(socket,&m->rows,sizeof(int));
    sendMSG(socket,&m->cols,sizeof(int));
    sendMSG(socket,m->data,(m->rows*m->cols*sizeof(int)));
    //Mandamos el path
    /*
    FILE* f=fopen(fileName,"w");
    fprintf(f,"%d %d\n",m->rows,m->cols);

    for(int i=0;i<m->rows*m->cols;i++)
        {
            fprintf(f,"%d\n",m->data[i]);
        }
    fclose(f);*/
}

/**
 * @brief createRandMatrix Método que crea una matriz con datos random de un tamaño dado
 * @param rows Número de filas
 * @param cols Número de columnas
 * @return Una estructura de tipo "matrix_t" con los datos rellenados
 */

matrix_t* multMatrix_stub::createRandMatrix(int rows, int cols)
{
    char* buffr=0x00;
    int* puntero=0x00;
    int bufferLen=0;
    matrix_t* m=new matrix_t[1];
    int typeOP=CRANDOM;
    sendMSG(socket,&typeOP,sizeof(int));

    //Mandamos filas y Cols
    sendMSG(socket,&rows,sizeof(int));
    sendMSG(socket,&cols,sizeof(int));

    //Recibir la matriz
    recvMSG(socket,(void**)&buffr,&bufferLen);
    m->rows=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&buffr,&bufferLen);
    m->cols=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&puntero,&bufferLen);
    m->data=puntero;
    //Hacemos la operacion despues como unos cracks
    /*
    m->rows=rows;
    m->cols=cols;
    m->data=new int[rows*cols];
    for(int i=0;i<rows*cols;i++)
        m->data[i]=rand()%1000;

    return m;*/
    return m;
}
/**
 * @brief createIdentity Método que crea una matriz identidad de un tamaño dado
 * @param rows Número de filas
 * @param cols Número de columnas
 * @return Una estructura de tipo "matrix_t" con los datos rellenados
 */
matrix_t* multMatrix_stub::createIdentity(int rows, int cols)
{   
    char* buffr=0x00;
    int* puntero=0x00;
    int bufferLen=0;
    matrix_t* m=new matrix_t[1];
    int typeOP=CIDENTY;
    sendMSG(socket,&typeOP,sizeof(int));

    //Mandamos filas y Cols
    sendMSG(socket,&rows,sizeof(int));
    sendMSG(socket,&cols,sizeof(int));

    //Recibir la matriz
    recvMSG(socket,(void**)&buffr,&bufferLen);
    m->rows=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&buffr,&bufferLen);
    m->cols=((int*)buffr)[0];
    delete[]buffr;

    recvMSG(socket,(void**)&puntero,&bufferLen);
    m->data=puntero;
    //Hacemos la operacion despues como unos cracks
    /*
    m->rows=rows;
    m->cols=cols;
    m->data=new int[rows*cols];
    memset(m->data,0,sizeof(int)*rows*cols);
    for(int i=0;i<rows;i++)
            m->data[i*cols+i]=1;
    return m;*/
    return m;
}


/**
 * @brief multMatrix::~multMatrix Destructor de la clase, no tiene nada ahora mismo
 */
multMatrix_stub::~multMatrix_stub()
{
    int opType=OP_EXIT;
    sendMSG(socket,&opType,sizeof(int));
}

