#include "multmatrix_imp.h"
#include <iostream>
#include <string.h>
#include "utils.h"

multmatrix_imp::multmatrix_imp(int clientID)
{
    
    client_fd=clientID;
    op=new multMatrix();

}

void multmatrix_imp::recvOp()
{
    //matrix_t* buffer=0x00;
    char* buffr=0x00;
    int bufferLen=0;
    int *puntero=0x00;
    int *puntero2=0x00;

    int typeOp=0;

    recvMSG(client_fd,(void**)&buffr,&bufferLen);
    typeOp=((int*)buffr)[0];
    delete[] buffr;

    switch(typeOp)
    {
        case EXIT:
        {
            this->salir=true;

        }break;

        case READ:
        {
            matrix_t* matrix=0x00;
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix=op->readMatrix(buffr);
            delete[] buffr;
            //Duda de si funciona 
            sendMSG(client_fd,&matrix->rows,sizeof(int));
            sendMSG(client_fd,&matrix->cols,sizeof(int));
            sendMSG(client_fd,matrix->data,(matrix->rows*matrix->cols*sizeof(int)));

            delete[] matrix;

        }break;

        case MULT:
        {
            
            //Creamos esas dos matrices completamente vacias para despues pillarlo
            matrix_t* matrix1=new matrix_t[1];
            matrix_t* matrix2=new matrix_t[1];
            //La matriz resultado
            matrix_t* matrixResultado=new matrix_t[1];
            //Recibimos la primera matrix 
            //Recibimos en este orden: 1º) Filas, 2º) Columnas, 3º) Data.
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix1->rows=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix1->cols=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&puntero,&bufferLen);
            matrix1->data=puntero;
           
            //Recibimos la segunda matrix
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix2->rows=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix2->cols=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&puntero2,&bufferLen);
            matrix2->data=puntero2;
            

            //Realizamos la operacion de la multiplicacion
            matrixResultado= op->multMatrices(matrix1,matrix2);

            //Preguntar si el size es de la matriz o del entero
            //sendMSG(client_fd,&matrixResultado,sizeof(int));

            sendMSG(client_fd,&matrixResultado->rows,sizeof(int));
            sendMSG(client_fd,&matrixResultado->cols,sizeof(int));
            sendMSG(client_fd,matrixResultado->data,(matrixResultado->rows*matrixResultado->cols*sizeof(int)));
            
            delete[] puntero;
            delete[] puntero2;
            delete[] buffr;
            

        }break;
        
        case WRITE:
        {
            //Recibimos una matrix y nombre del fichero que queremos guardarlo
            matrix_t* matrix=new matrix_t[1];
            char* path;
            //Recibimos ahora el path
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            path=buffr;
            //Recibimos la matrix
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix->rows=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            matrix->cols=((int*)buffr)[0];
            delete[] buffr;

            recvMSG(client_fd,(void**)&puntero,&bufferLen);
            matrix->data=puntero;
            

            op->writeMatrix(matrix,path);
            //Aqui no se si mandar el tamaño del path o de la matriz
            //sendMSG(client_fd,&matrixResutlado,sizeof(int));
            delete[] path;
            delete[] puntero;
        }break;

        case CIDENTY:
        {
            //Recibiremos la columnas y filas. Recibiremos la matrix identidad
            int rows=0;
            int cols=0;
            matrix_t* matrixResultado=new matrix_t[1];
            //Recibimos las filas(rows)
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            rows=((int*)buffr)[0];
            delete[] buffr;
            //Recibimos las columnas(cols)
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            cols=((int*)buffr)[0];
            delete[] buffr;
            
            //Realizamos la operacion
            matrixResultado=op-> createIdentity(rows,cols);

            //Sigo con la misma duda
            //sendMSG(client_fd,&matrixResutlado,sizeof(matrix_t));

            sendMSG(client_fd,&matrixResultado->rows,sizeof(int));
            sendMSG(client_fd,&matrixResultado->cols,sizeof(int));
            sendMSG(client_fd,matrixResultado->data,(matrixResultado->rows*matrixResultado->cols*sizeof(int)));

        }break;

        case CRANDOM:
        {
            //Recibiremos la columnas y filas. Recibiremos la matrix identidad
            int rows=0;
            int cols=0;
            matrix_t* matrixResultado=new matrix_t[1];
            //Recibimos las filas(rows)
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            rows=((int*)buffr)[0];
            delete[] buffr;
            //Recibimos las columnas(cols)
            recvMSG(client_fd,(void**)&buffr,&bufferLen);
            cols=((int*)buffr)[0];
            delete[] buffr;
            //Realizamos la operacion
            matrixResultado=op-> createRandMatrix(rows,cols);

            //Sigo con la misma duda
            //sendMSG(client_fd,&matrixResutlado,sizeof(matrix_t));

            sendMSG(client_fd,&matrixResultado->rows,sizeof(int));
            sendMSG(client_fd,&matrixResultado->cols,sizeof(int));
            sendMSG(client_fd,matrixResultado->data,(matrixResultado->rows*matrixResultado->cols*sizeof(int)));

        }break;

        default:
        {
            std::cout<<"ERROR: operación no reconocida\n";
            exit(0);
        }break;    


    }
}
multmatrix_imp::~multmatrix_imp()
{
    closeConnection(client_fd);
    delete op;

}