#ifndef OPERACIONES_STUB_H
#define OPERACIONES_STUB_H

#define OP_EXIT -1
#define OP_READ 0
#define OP_MULTIPLIACION 1
#define OP_WRITE 2
#define OP_CREATEIDENTIDAD 3
#define OP_RANDOMMATRIX 4

#include "multmatrix.h"

class multMatrix_stub
{
    int socket=0;
public:
    multMatrix_stub();
    matrix_t* readMatrix(const char* fileName);
    matrix_t *multMatrices(matrix_t* m1, matrix_t *m2);
    void writeMatrix(matrix_t* m, const char *fileName);
    ~multMatrix_stub();
    matrix_t *createIdentity(int rows, int cols);
    matrix_t *createRandMatrix(int rows, int cols);
};

#endif // MULTMATRIX_H


