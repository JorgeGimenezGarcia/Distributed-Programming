#include "utils.h"
#include "multmatrix_stub.h"
#include <iostream>
#include <string>


void freeMatrix(matrix_t* m){
    delete[] m->data;
    delete[] m;

}

int main(int argc, char** argv)
{
    multMatrix_stub* mtx=new multMatrix_stub();

    matrix_t* m1= mtx->createRandMatrix(5,5);
    matrix_t* m2= mtx->createIdentity(5,5);
    matrix_t* mres= mtx->multMatrices(m1,m2);
    mtx->writeMatrix(mres,"resultado_stub.txt");
    
    matrix_t* m3=mtx->readMatrix("resultado_stub.txt");

    matrix_t* mres2=mtx->multMatrices(m1,m3);
    mtx->writeMatrix(mres2,"resultado2_stub.txt");

    matrix_t* m4=mtx->readMatrix("resultado2_stub.txt");


    freeMatrix(m1);
    freeMatrix(m2);
    freeMatrix(mres);
    freeMatrix(m3);
    freeMatrix(m4);
    freeMatrix(mres2);
    delete mtx;

    return 0;
    
}
