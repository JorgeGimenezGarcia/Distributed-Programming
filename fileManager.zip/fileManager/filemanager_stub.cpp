#include "filemanager_stub.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <cstring>
#include <sys/types.h>
#include <unistd.h>

fileManager_stub::fileManager_stub()
{
    //socket=initClient("192.168.0.113",8081);
}
/**
 * @brief FileManager::FileManager Constructor de la clase FileManager. Recibe por parámetros el directorio
 * que usará esta clase para indexar, almacenar y leer ficheros. Se aconseja usar una ruta completa al directorio,
 * desde la raiz del sistema de ficheros.
 *
 * @param path Ruta al directorio que se desa usar
 */

fileManager_stub::fileManager_stub(string path)
{
    socket=initClient("192.168.0.115",8081);
    int typeOP=INIT_DIR;
    sendMSG(socket,&typeOP,sizeof(int));
    sendMSG(socket,path.c_str(),path.length()+1);
    /*
    this->dirPath=path;
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir(path.c_str())) != nullptr) {
       print all the files and directories within directory 
      while ((ent = readdir (dir)) != nullptr) {
          if(ent->d_type==DT_REG) //Store only regular files
          {
           string* f=new string(ent->d_name);
           this->files[*f]=f;
          }
      }
      closedir (dir);
    } else {
       could not open directory 
        string* f=new string("ERROR: No existe el fichero o directorio");
        this->files[*f]=f;
        std::cout<<"ERROR: No existe el fichero o directorio\n";
    }*/
}

/**
 * @brief FileManager::listFiles Sirve para acceder a la lista de ficheros almacenados en la ruta
 * que se usó en el contructor de la clase
 * @return Una copia de la lista de ficheros almacenada en "files". Esta copia hay que liberarla
 * después de haber sido usada. Para ello se ofrece la función "freeListedFiles"
 */
vector<string*>* fileManager_stub::listFiles(){

    //Parametros
    char* buffr=0x00;
    char* nombre=0x00;
    int bufferLen=0;
    int tamanioMensaje=0;
    int typeOp=OP_LIST;
    //Mandamos el tipo de operacion
    sendMSG(socket,&typeOp,sizeof(int));

    vector<string*>* lista;
    lista=new vector<string*>();
    int nFicheros=0;
    //Recibimos el numero de ficheros
    recvMSG(socket,(void**)&buffr,&bufferLen);
    nFicheros=((int*)buffr)[0];
    delete[] buffr;

    //Listamos los ficheros
    for(int i=0;i<nFicheros;i++)
    {
        //Recibimos la longuitud del mensaje
        recvMSG(socket,(void**)&buffr,&bufferLen);
        tamanioMensaje=((int*)buffr)[0];
        delete[] buffr;

        //Recibimos el nombre
        recvMSG(socket,(void**)&buffr,&bufferLen);
        nombre=buffr;
        lista->push_back(new string (nombre));
        delete[] nombre;

    }

    /*
    vector<string*>* flist=new vector<string*>();
    for(map<string,string*>::iterator i=files.begin();i!= files.end();++i)
    {
        flist->push_back(new string(i->first));
    }*/

    return lista;
}
/**
 * @brief FileManager::freeListedFiles Función de apoyo, libera una lista de ficheros devuelta por la función "listFiles"
 * @param fileList Puntero a una lista de strings devuelta por la función "listFiles"
 */
void fileManager_stub::freeListedFiles(vector<string*>* fileList)
{
    for(vector<string*>::iterator i=fileList->begin();i!= fileList->end();++i)
    {
        delete *i;
    }
    delete fileList;
}
/**
 * @brief FileManager::readFile Dado el nombre de un fichero almacenado en el directorio que se usó en el contructor,
 * se inicializará la variable "data" con un puntero al contenido del fichero, y la variable dataLength con el
 * tamaño del mismo en bytes.
 *
 * @param fileName Nombre del fichero a leer
 * @param data Datos del fichero. Deberá de liberarse después de ser usado
 * @param dataLength Longitud del fichero en bytes
 */

void fileManager_stub::readFile(char* fileName, char* &data, unsigned long int & dataLength)
{
    //
    char* buffr=0x00;
    //int dataLen=0;
    int bufferLen=0;
    int fileLen=0;

    int typeOp=OP_READ;
    //Para mandar el tipo de operacion
    sendMSG(socket,&typeOp,sizeof(int));

    int filenameLen=strlen(fileName)+1;
    //Mandamos el tamaño del nombre del fichero
    sendMSG(socket,&filenameLen,filenameLen);
    //Mandamos el nombre del fichero
    sendMSG(socket,fileName,filenameLen);
    //Recibes el tamaño del fichero

    recvMSG(socket,(void**)&buffr,&bufferLen);
    dataLength=((int*)buffr)[0];
    delete[] buffr;
    //Recibes el nombre del fichero
    recvMSG(socket,(void**)&buffr,&bufferLen);
    data=buffr;
    //dalaLength=bufferLength;
    //
    //delete[] buffr;



    /*
    //Mandar mensaje para poder 
    //Enviamos Longuitud del
    int filenameLen=strlen(fileName)+1;
    sendMSG(socket,&filenameLen,filenameLen);
    //Mandamos el filename
    sendMSG(socket,fileName,sizeof(int));
    //Mandamos el data
    sendMSG(socket,data,strlen(data)+1);    
    */

    /*
    string path=this->dirPath+"/"+string(fileName);
    FILE* f=fopen(path.c_str(),"r");

    fseek(f, 0L, SEEK_END);
    dataLength= ftell(f);
    fseek(f, 0L, SEEK_SET);
    data=new char[dataLength];

    fread(data,dataLength,1,f);
    fclose(f);*/
}


/**
 * @brief FileManager::readFile Dado un nuevo nombre de un fichero que se quiere almacenar  en el directorio que se usó en el contructor,
 * se escribirá el contenido del array de datos almacenado en "data", siendo dataLength el
 * tamaño del mismo en bytes. Sobreescribirá el fichero que hubiera en el directorio si tiene el mismo nombre.
 *
 * @param fileName Nombre del fichero a escribir
 * @param data Datos del fichero. Deberá de liberarse después de ser usado
 * @param dataLength Longitud del fichero en bytes
 */

void fileManager_stub::writeFile(char* fileName, char* data, unsigned long int  dataLength)
{
    
    int typeOp=OP_WRITE;
    sendMSG(socket,&typeOp,sizeof(int));
    //Mandamos longuitud del fichero
    int fileLen=strlen(fileName)+1;
    sendMSG(socket,&fileLen,sizeof(int));
    //Mandamos ahora el fichero
    sendMSG(socket,fileName,fileLen);

    //Mandamos el tamaño del data
    sendMSG(socket,&dataLength,sizeof(int));
    //Ahora mandamos el data
    sendMSG(socket,data,dataLength);

    /*
    string path=this->dirPath+"/"+string(fileName);
    FILE* f=fopen(path.c_str(),"w");
    fwrite(data,dataLength,1,f);
    fclose(f);
//añadir a la lista el nuevo fichero, si no existe ya
    if(files.find(string(fileName))==files.end())
        files[ string(fileName)]=new string(fileName);*/

}
fileManager_stub::~fileManager_stub()
{
    int op=OP_EXIT;
    sendMSG(socket,&op,sizeof(int));
}
