#ifndef OPERACIONES_IMP_H
#define OPERACIONES_IMP_H
#include "multmatrix.h"

class multmatrix_imp
{
    int client_fd=0;
    multMatrix* op;

    public:
    multmatrix_imp(int socket_fd);
    void recvOp();
    ~multmatrix_imp();

    bool salir =false;
};

#endif //OPERACIONES_IMP_H