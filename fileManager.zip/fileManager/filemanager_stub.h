#ifndef FILEMANAGER_STUB_H
#define FILEMANAGER_STUB_H

#include "filemanager.h"
#include "utils.h"
#include <string.h>
#include <iostream>

//Operaciones del filemanager-
#define OP_EXIT -1
#define OP_LIST 0
#define OP_READ 1
#define OP_WRITE 2
#define OP_FREELIST 3
#define INIT_DIR 4

using namespace std;

class fileManager_stub
{
    int socket=0;
    string dirPath;
    map<string, string* > files;

public:
    fileManager_stub();
    fileManager_stub(string path);
    vector<string*>* listFiles();
    void readFile(char* fileName,char* &data, unsigned long int & dataLength);
    void writeFile(char* fileName,char* data, unsigned long int  dataLength);
    void freeListedFiles(vector<string*>* fileList);
    ~fileManager_stub();
};

#endif // FILEMANAGER_STUB_H

