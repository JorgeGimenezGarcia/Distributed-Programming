#ifndef MULTMATRIX_H
#define MULTMATRIX_H

#define EXIT -1
#define READ 0
#define MULT 1
#define WRITE 2
#define CIDENTY 3
#define CRANDOM 4

#include "utils.h"

typedef struct matrix_t
{
    int rows;
    int cols;
    int* data;
}matrix_t;

class multMatrix
{
public:
    multMatrix();
    matrix_t* readMatrix(const char* fileName);
    matrix_t *multMatrices(matrix_t* m1, matrix_t *m2);
    void writeMatrix(matrix_t* m, const char *fileName);
    matrix_t *createIdentity(int rows, int cols);
    matrix_t *createRandMatrix(int rows, int cols);
    ~multMatrix();
};

#endif // MULTMATRIX_H
