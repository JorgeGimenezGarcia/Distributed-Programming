#ifndef FILEMANAGER_IMP_H
#define FILEMANAGER_IMP_H
#include"utils.h"
#include"filemanager.h"

#define OP_EXIT -1
#define OP_LIST 0
#define OP_READ 1
#define OP_WRITE 2
#define OP_FREELIST 3
#define INIT_DIR 4

class filemanager_imp
{
    int client_fd=0;
    FileManager* fileman=0x00;
    

public:
    filemanager_imp(int clientID);
    void run();
    ~filemanager_imp();

    bool salir=false;
};

#endif // FILEMANAGER_IMP_H